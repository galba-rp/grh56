<!DOCTYPE html>
<html lang="fr">

    <head>
    <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="app/public/css/style.css">
        <link rel="stylesheet" href="app/public/css/media_queries.css">
        <link rel="stylesheet" href="app/public/css/js_classes.css">
        <link rel="stylesheet" href="app/public/css/animation.css"> 
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
       
        <title>GRH formation</title>
        <meta name='description' content=''/>
        <meta name='keywords' content=''/>
    </head>
    <body class="none">