$(document).ready(function () {
    $(".fade_in_menu").each(function () {
        $(this).delay(600).fadeIn(1000);
    })

})