<?php 
include 'app/views/FRONT/layouts/head.php';
include_once 'app/views/FRONT/layouts/header.php';
?>
<main>
<section class="normal_width">
    <div class="error">
        <h1>Oupss! It did not work :( </h1>
        <p> Please try agian or let us know about </br>this incident at blablabla.error@gmail.com</p>
    </div>
</section>
</main>
<?php include 'app/views/FRONT/layouts/footer.php' ?>   