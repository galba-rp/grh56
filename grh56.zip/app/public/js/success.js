$(document).ready(function () {

    $("#messsage_ok").on("click", function () {
        console.log("here");
        $("#message_modal").removeClass("show");
    })



})